import '../models/models.dart';

class MockData {
  // ── Workshop options ─────────────────────────────────────────
  static const workshopOptions = [
    'Yoga Level 1',
    'Yoga Level 2',
    'Yoga Level 3',
    'Pranayama Basics',
    'Meditation Fundamentals',
    'AUWA Foundation',
    'Crystal/PSP Course',
    'HDP Level 1',
  ];

  // ── Level options ────────────────────────────────────────────
  static const levelOptions = [
    'Level 1',
    'Level 2',
    'Level 3',
    'AUWA',
    'Crystal/PSP',
    'HDP1',
    'Arhat Trainer',
  ];

  // ── Current trainer (mock session) ──────────────────────────
  static final trainer = TrainerModel(
    id: 'T001',
    name: 'Priya Sharma',
    phone: '+91 98765 43210',
    email: 'priya@ypv.org',
    level: 'Level 2',
    registrationDate: '15 Jan 2024',
    studentCount: 5,
  );

  // ── Current student (mock session) ──────────────────────────
  static const currentStudent = StudentModel(
    id: 'S001',
    name: 'Aisha Nair',
    email: 'aisha@example.com',
    phone: '+91 87654 32100',
    level: 'Level 1',
    trainerName: 'Priya Sharma',
    workshopHistory: [
      WorkshopRecord(
        workshopName: 'Yoga Level 1',
        completionDate: '12 Mar 2024',
        certificateNumber: 'YPV-2024-001',
        trainerName: 'Priya Sharma',
      ),
    ],
  );

  // ── Student list (trainer's students) ───────────────────────
  static List<StudentModel> students = [
    const StudentModel(
      id: 'S001', name: 'Aisha Nair', email: 'aisha@example.com',
      phone: '+91 87654 32100', level: 'Level 1', trainerName: 'Priya Sharma',
      workshopHistory: [WorkshopRecord(workshopName: 'Yoga Level 1', completionDate: '12 Mar 2024', certificateNumber: 'YPV-2024-001', trainerName: 'Priya Sharma')],
    ),
    const StudentModel(
      id: 'S002', name: 'Karthik Mehta', email: 'karthik@example.com',
      phone: '+91 76543 21098', level: 'Level 2', trainerName: 'Priya Sharma',
      workshopHistory: [
        WorkshopRecord(workshopName: 'Yoga Level 2', completionDate: '15 Apr 2024', certificateNumber: 'YPV-2024-045', trainerName: 'Priya Sharma'),
        WorkshopRecord(workshopName: 'Yoga Level 1', completionDate: '20 Jan 2024', certificateNumber: 'YPV-2024-002', trainerName: 'Priya Sharma'),
      ],
    ),
    const StudentModel(
      id: 'S003', name: 'Sneha Pillai', email: 'sneha@example.com',
      phone: '+91 65432 10987', level: 'Level 1', trainerName: 'Priya Sharma',
      workshopHistory: [WorkshopRecord(workshopName: 'Pranayama Basics', completionDate: '5 May 2024', certificateNumber: 'YPV-2024-078', trainerName: 'Priya Sharma')],
    ),
    const StudentModel(
      id: 'S004', name: 'Raj Verma', email: 'raj@example.com',
      phone: '+91 54321 09876', level: 'Level 1', trainerName: 'Priya Sharma',
      workshopHistory: [WorkshopRecord(workshopName: 'Meditation Fundamentals', completionDate: '2 Jun 2024', certificateNumber: 'YPV-2024-102', trainerName: 'Priya Sharma')],
    ),
    const StudentModel(
      id: 'S005', name: 'Meena Das', email: 'meena@example.com',
      phone: '+91 43210 98765', level: 'Level 1', trainerName: 'Priya Sharma',
      workshopHistory: [WorkshopRecord(workshopName: 'Meditation Fundamentals', completionDate: '18 Jun 2024', certificateNumber: 'YPV-2024-115', trainerName: 'Priya Sharma')],
    ),
  ];

  static StudentModel? findStudentByCert(String cert) {
    for (final s in students) {
      for (final w in s.workshopHistory) {
        if (w.certificateNumber.toLowerCase() == cert.toLowerCase()) return s;
      }
    }
    return null;
  }
}
