class WorkshopRecord {
  final String workshopName;
  final String completionDate;
  final String certificateNumber;
  final String trainerName;

  const WorkshopRecord({
    required this.workshopName,
    required this.completionDate,
    required this.certificateNumber,
    required this.trainerName,
  });
}

class StudentModel {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String level;
  final String trainerName;
  final List<WorkshopRecord> workshopHistory;

  const StudentModel({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.level,
    required this.trainerName,
    required this.workshopHistory,
  });

  String get latestCert =>
      workshopHistory.isNotEmpty ? workshopHistory.first.certificateNumber : '—';

  int get workshopCount => workshopHistory.length;
}

class TrainerModel {
  final String id;
  final String name;
  final String phone;
  final String email;
  final String level;
  final String registrationDate;
  int studentCount;

  TrainerModel({
    required this.id,
    required this.name,
    required this.phone,
    required this.email,
    required this.level,
    required this.registrationDate,
    required this.studentCount,
  });
}

enum UserRole { trainer, student }
