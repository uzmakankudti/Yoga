import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';
import '../../widgets/common_widgets.dart';

class StudentRegistrationScreen extends StatefulWidget {
  const StudentRegistrationScreen({super.key});
  @override State<StudentRegistrationScreen> createState() => _State();
}

class _State extends State<StudentRegistrationScreen> {
  final _nameCtrl  = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  bool _loading = false;

  bool get _valid => _nameCtrl.text.isNotEmpty &&
      _emailCtrl.text.isNotEmpty && _phoneCtrl.text.isNotEmpty;

  void _submit() async {
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() => _loading = false);
    showYPVToast(context, 'OTP sent to ${_phoneCtrl.text}');
    context.go('/login');
  }

  @override
  void dispose() { _nameCtrl.dispose(); _emailCtrl.dispose(); _phoneCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Create Student Account'),
        leading: BackButton(onPressed: () => context.go('/login'))),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Create your student account to view courses and certificate records.',
            style: TextStyle(fontSize: 13, letterSpacing: 0.5,
                color: AppColors.muted, height: 1.6)),
        const SizedBox(height: 24),
        TextField(controller: _nameCtrl, onChanged: (_) => setState((){}),
            decoration: const InputDecoration(labelText: 'Full Name *',
                hintText: 'Aisha Nair')),
        const SizedBox(height: 14),
        TextField(controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            onChanged: (_) => setState((){}),
            decoration: const InputDecoration(labelText: 'Email ID *',
                hintText: 'aisha@example.com', helperText: 'Must be unique')),
        const SizedBox(height: 14),
        TextField(controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            onChanged: (_) => setState((){}),
            decoration: const InputDecoration(labelText: 'Phone Number *',
                hintText: '+91 98765 43210')),
        const SizedBox(height: 28),
        PrimaryButton(label: 'Register & Send OTP',
            loading: _loading, onPressed: _valid ? _submit : null),
        const SizedBox(height: 14),
        Center(child: TextButton(
          onPressed: () => context.go('/login'),
          child: const Text('Already have an account? Login',
              style: TextStyle(color: AppColors.muted, fontSize: 13)),
        )),
      ]),
    ),
  );
}
