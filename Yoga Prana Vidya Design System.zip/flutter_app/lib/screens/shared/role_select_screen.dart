import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';

class RoleSelectScreen extends StatelessWidget {
  const RoleSelectScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.white,
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle, color: AppColors.primary, size: 56),
            const SizedBox(height: 20),
            const Text("You're verified!", style: TextStyle(fontSize: 22,
                fontWeight: FontWeight.w500, letterSpacing: 0.5, color: AppColors.ink)),
            const SizedBox(height: 8),
            const Text('Choose your role to continue',
                style: TextStyle(fontSize: 14, letterSpacing: 0.5, color: AppColors.muted)),
            const SizedBox(height: 36),
            _RoleCard(
              label: "I'm a Trainer",
              desc: 'Add & manage students',
              icon: Icons.school_outlined,
              bg: AppColors.primaryTint,
              border: AppColors.primary,
              color: AppColors.primary,
              onTap: () => context.go('/trainer/home'),
            ),
            const SizedBox(height: 16),
            _RoleCard(
              label: "I'm a Student",
              desc: 'View my courses & certificates',
              icon: Icons.self_improvement,
              bg: AppColors.tealTint,
              border: AppColors.teal,
              color: AppColors.teal,
              onTap: () => context.go('/student/home'),
            ),
          ],
        ),
      ),
    ),
  );
}

class _RoleCard extends StatelessWidget {
  final String label, desc;
  final IconData icon;
  final Color bg, border, color;
  final VoidCallback onTap;
  const _RoleCard({required this.label, required this.desc, required this.icon,
    required this.bg, required this.border, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(4),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(color: bg,
          border: Border.all(color: border, width: 1.5),
          borderRadius: BorderRadius.circular(4)),
      child: Row(children: [
        Container(width: 48, height: 48,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.6),
                borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 26)),
        const SizedBox(width: 16),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600,
              letterSpacing: 0.5, color: color)),
          const SizedBox(height: 4),
          Text(desc, style: const TextStyle(fontSize: 13, letterSpacing: 0.5,
              color: AppColors.muted)),
        ])),
        Icon(Icons.arrow_forward_ios, color: color, size: 16),
      ]),
    ),
  );
}
