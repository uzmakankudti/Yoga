import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';
import '../../data/mock_data.dart';
import '../../widgets/common_widgets.dart';

class TrainerRegistrationScreen extends StatefulWidget {
  const TrainerRegistrationScreen({super.key});
  @override State<TrainerRegistrationScreen> createState() => _State();
}

class _State extends State<TrainerRegistrationScreen> {
  final _nameCtrl  = TextEditingController();
  final _phoneCtrl = TextEditingController();
  String _level = '';
  bool _loading = false;

  bool get _valid => _nameCtrl.text.isNotEmpty &&
      _phoneCtrl.text.isNotEmpty && _level.isNotEmpty;

  void _submit() async {
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() => _loading = false);
    showYPVToast(context, 'OTP sent to ${_phoneCtrl.text}');
    context.go('/login');
  }

  @override
  void dispose() { _nameCtrl.dispose(); _phoneCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Register as Trainer'),
        leading: BackButton(onPressed: () => context.go('/login'))),
    body: SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Create your trainer account to start adding students.',
            style: TextStyle(fontSize: 13, letterSpacing: 0.5,
                color: AppColors.muted, height: 1.6)),
        const SizedBox(height: 24),
        TextField(controller: _nameCtrl, onChanged: (_) => setState((){}),
            decoration: const InputDecoration(labelText: 'Full Name *',
                hintText: 'Priya Sharma')),
        const SizedBox(height: 14),
        TextField(controller: _phoneCtrl,
            keyboardType: TextInputType.phone,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            onChanged: (_) => setState((){}),
            decoration: const InputDecoration(labelText: 'Phone Number *',
                hintText: '+91 98765 43210')),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _level.isEmpty ? null : _level,
          decoration: const InputDecoration(labelText: 'YPV Trainer Level *'),
          hint: const Text('Select your level'),
          items: MockData.levelOptions.map((l) =>
              DropdownMenuItem(value: l, child: Text(l))).toList(),
          onChanged: (v) => setState(() => _level = v ?? ''),
        ),
        const SizedBox(height: 28),
        PrimaryButton(label: 'Register & Send OTP',
            loading: _loading, onPressed: _valid ? _submit : null),
        const SizedBox(height: 14),
        Center(child: TextButton(
          onPressed: () => context.go('/login'),
          child: const Text('Already registered? Login',
              style: TextStyle(color: AppColors.muted, fontSize: 13)),
        )),
      ]),
    ),
  );
}
