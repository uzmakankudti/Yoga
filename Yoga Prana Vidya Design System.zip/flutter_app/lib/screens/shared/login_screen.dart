import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';
import '../../widgets/common_widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final _phoneCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  int _step = 1; // 1 = enter identifier, 2 = enter OTP
  String _otp = '';
  bool _loading = false;
  int _countdown = 0;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabCtrl.dispose(); _phoneCtrl.dispose(); _emailCtrl.dispose();
    super.dispose();
  }

  String get _identifier =>
      _tabCtrl.index == 0 ? _phoneCtrl.text : _emailCtrl.text;

  void _sendOTP() async {
    if (_identifier.isEmpty) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() { _loading = false; _step = 2; _countdown = 30; });
    _startCountdown();
  }

  void _startCountdown() async {
    while (_countdown > 0 && mounted) {
      await Future.delayed(const Duration(seconds: 1));
      if (mounted) setState(() => _countdown--);
    }
  }

  void _verify() async {
    if (_otp.length < 6) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    setState(() => _loading = false);
    context.go('/role-select');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppColors.white,
    body: SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          const SizedBox(height: 48),
          Container(
            width: 64, height: 64,
            decoration: BoxDecoration(color: AppColors.primaryTint,
                borderRadius: BorderRadius.circular(16)),
            child: const Center(
              child: Text('YPV', style: TextStyle(fontSize: 18,
                  fontWeight: FontWeight.w700, color: AppColors.primary)),
            ),
          ),
          const SizedBox(height: 20),
          Text(_step == 1 ? 'Login' : 'Enter OTP',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w500,
                  letterSpacing: 0.5, color: AppColors.ink)),
          const SizedBox(height: 6),
          if (_step == 2)
            Text('Sent to ${_tabCtrl.index == 0 ? "+91 ****${_identifier.length > 4 ? _identifier.substring(_identifier.length - 4) : '****'}" : "${_identifier.substring(0,3)}***"}',
                style: const TextStyle(fontSize: 13, letterSpacing: 0.5, color: AppColors.muted)),
          const SizedBox(height: 28),

          if (_step == 1) ...[
            // Tab selector
            Container(
              height: 44, padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(color: AppColors.bg,
                  borderRadius: BorderRadius.circular(10)),
              child: TabBar(
                controller: _tabCtrl,
                indicator: BoxDecoration(color: AppColors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08),
                        blurRadius: 4, offset: const Offset(0, 1))]),
                labelColor: AppColors.ink,
                unselectedLabelColor: AppColors.muted,
                labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                    letterSpacing: 0.5),
                unselectedLabelStyle: const TextStyle(fontSize: 13, letterSpacing: 0.5),
                tabs: const [Tab(text: 'Phone'), Tab(text: 'Email')],
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 56,
              child: TabBarView(
                controller: _tabCtrl,
                children: [
                  TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    decoration: const InputDecoration(
                      labelText: 'Phone Number',
                      hintText: '+91 98765 43210',
                      prefixIcon: Icon(Icons.phone_outlined, size: 18),
                    ),
                  ),
                  TextField(
                    controller: _emailCtrl,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email Address',
                      hintText: 'name@email.com',
                      prefixIcon: Icon(Icons.email_outlined, size: 18),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Send OTP', loading: _loading,
                onPressed: _identifier.isNotEmpty ? _sendOTP : null),
            const SizedBox(height: 16),
            TextButton(
              onPressed: () => context.push('/trainer-reg'),
              child: const Text('New here? Register as Trainer',
                  style: TextStyle(color: AppColors.primary, fontSize: 13, letterSpacing: 0.5)),
            ),
          ] else ...[
            // OTP step
            OtpInput(onChanged: (v) => setState(() => _otp = v)),
            const SizedBox(height: 20),
            PrimaryButton(label: 'Verify & Continue', loading: _loading,
                onPressed: _otp.length == 6 ? _verify : null),
            const SizedBox(height: 12),
            _countdown > 0
              ? Text('Resend in 0:${_countdown.toString().padLeft(2, '0')}',
                  style: const TextStyle(fontSize: 13, letterSpacing: 0.5, color: AppColors.muted))
              : TextButton(
                  onPressed: () { setState(() { _otp = ''; _countdown = 30; }); _startCountdown(); },
                  child: const Text('Resend OTP',
                      style: TextStyle(color: AppColors.primary, fontSize: 13))),
            TextButton(
              onPressed: () => setState(() { _step = 1; _otp = ''; }),
              child: const Text('Change number / email',
                  style: TextStyle(color: AppColors.muted, fontSize: 12)),
            ),
          ],

          // Demo quick-access
          const SizedBox(height: 32),
          const Divider(),
          const SizedBox(height: 16),
          const Text('DEMO — SKIP OTP',
              style: TextStyle(fontSize: 10, letterSpacing: 1.5, color: AppColors.muted)),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: SecondaryButton(label: 'Trainer',
                onPressed: () => context.go('/trainer/home'))),
            const SizedBox(width: 12),
            Expanded(child: SecondaryButton(label: 'Student',
                color: AppColors.teal,
                onPressed: () => context.go('/student/home'))),
          ]),
          const SizedBox(height: 24),
        ]),
      ),
    ),
  );
}
