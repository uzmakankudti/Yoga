import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';
import '../../data/mock_data.dart';
import '../../widgets/common_widgets.dart';

class StudentDetailScreen extends StatelessWidget {
  final String studentId;
  const StudentDetailScreen({super.key, required this.studentId});

  @override
  Widget build(BuildContext context) {
    final s = MockData.students.firstWhere(
      (x) => x.id == studentId,
      orElse: () => MockData.students.first,
    );
    final isL2Plus = MockData.trainer.level != 'Level 1';

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        title: const Text('Student Profile'),
        actions: [
          if (isL2Plus)
            TextButton.icon(
              onPressed: () => context.push('/trainer/upgrade-student'),
              icon: const Icon(Icons.upgrade, size: 18),
              label: const Text('Upgrade'),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          // ── Header card ────────────────────────────────────
          WhiteCard(
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              YPVAvatar(name: s.name, size: 56),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.name, style: const TextStyle(fontSize: 17,
                    fontWeight: FontWeight.w500, letterSpacing: 0.5, color: AppColors.ink)),
                const SizedBox(height: 4),
                Text(s.email, style: const TextStyle(fontSize: 12,
                    letterSpacing: 0.5, color: AppColors.muted)),
                Text(s.phone, style: const TextStyle(fontSize: 12,
                    letterSpacing: 0.5, color: AppColors.muted)),
                const SizedBox(height: 8),
                LevelBadge(s.level),
              ])),
            ]),
          ),
          const SizedBox(height: 16),

          // ── Workshop history ───────────────────────────────
          const Text('WORKSHOP HISTORY',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600,
                  letterSpacing: 1.5, color: AppColors.muted)),
          const SizedBox(height: 10),
          ...s.workshopHistory.map((w) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: WhiteCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(w.workshopName, style: const TextStyle(fontSize: 14,
                    fontWeight: FontWeight.w500, letterSpacing: 0.5, color: AppColors.ink)),
                const SizedBox(height: 10),
                const Divider(),
                const SizedBox(height: 8),
                Row(children: [
                  const Icon(Icons.calendar_today_outlined,
                      size: 14, color: AppColors.muted),
                  const SizedBox(width: 8),
                  Text(w.completionDate, style: const TextStyle(fontSize: 12,
                      letterSpacing: 0.5, color: AppColors.muted)),
                  const Spacer(),
                  const Icon(Icons.workspace_premium_outlined,
                      size: 14, color: AppColors.primary),
                  const SizedBox(width: 6),
                  Text(w.certificateNumber, style: const TextStyle(fontSize: 12,
                      fontWeight: FontWeight.w600, letterSpacing: 0.5,
                      color: AppColors.primary)),
                ]),
              ]),
            ),
          )),

          if (isL2Plus) ...[
            const SizedBox(height: 8),
            SecondaryButton(
              label: 'Upgrade this Student',
              onPressed: () => context.push('/trainer/upgrade-student'),
            ),
          ],
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
