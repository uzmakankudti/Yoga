import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../theme/app_colors.dart';
import '../../data/mock_data.dart';
import '../../widgets/common_widgets.dart';

class AddStudentScreen extends StatefulWidget {
  const AddStudentScreen({super.key});
  @override State<AddStudentScreen> createState() => _State();
}

class _State extends State<AddStudentScreen> {
  final _nameCtrl  = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _certCtrl  = TextEditingController();
  String _workshop = '';
  DateTime? _date;
  bool _loading = false;
  final _formKey = GlobalKey<FormState>();

  bool get _valid => _nameCtrl.text.isNotEmpty && _emailCtrl.text.isNotEmpty &&
      _workshop.isNotEmpty && _date != null && _certCtrl.text.isNotEmpty;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2010),
      lastDate: DateTime.now(),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(primary: AppColors.primary)),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _date = picked);
  }

  void _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 1000));
    if (!mounted) return;
    setState(() => _loading = false);
    showYPVToast(context, 'Student added successfully ✓');
    context.pop();
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _emailCtrl.dispose(); _certCtrl.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Add New Student')),
    body: Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          WhiteCard(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // Name
              TextFormField(
                controller: _nameCtrl,
                onChanged: (_) => setState((){}),
                validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                decoration: const InputDecoration(labelText: 'Student Full Name *',
                    hintText: 'Aisha Nair'),
              ),
              const SizedBox(height: 14),

              // Email
              TextFormField(
                controller: _emailCtrl,
                keyboardType: TextInputType.emailAddress,
                onChanged: (_) => setState((){}),
                validator: (v) {
                  if (v?.isEmpty ?? true) return 'Required';
                  if (!v!.contains('@')) return 'Enter a valid email';
                  return null;
                },
                decoration: const InputDecoration(labelText: 'Student Email ID *',
                    hintText: 'aisha@example.com', helperText: 'Must be unique'),
              ),
              const SizedBox(height: 14),

              // Workshop dropdown
              DropdownButtonFormField<String>(
                value: _workshop.isEmpty ? null : _workshop,
                decoration: const InputDecoration(labelText: 'Workshop Name *'),
                hint: const Text('Select workshop'),
                items: MockData.workshopOptions.map((w) =>
                    DropdownMenuItem(value: w, child: Text(w))).toList(),
                onChanged: (v) => setState(() => _workshop = v ?? ''),
                validator: (v) => (v == null || v.isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 14),

              // Date picker
              GestureDetector(
                onTap: _pickDate,
                child: AbsorbPointer(
                  child: TextFormField(
                    readOnly: true,
                    decoration: InputDecoration(
                      labelText: 'Workshop Completion Date *',
                      hintText: 'Tap to select',
                      suffixIcon: const Icon(Icons.calendar_today_outlined, size: 18),
                      suffixText: _date != null
                          ? '${_date!.day}/${_date!.month}/${_date!.year}' : '',
                    ),
                    controller: TextEditingController(
                        text: _date != null
                            ? '${_date!.day} ${_monthName(_date!.month)} ${_date!.year}'
                            : ''),
                    validator: (_) => _date == null ? 'Required' : null,
                  ),
                ),
              ),
              const SizedBox(height: 14),

              // Certificate number
              TextFormField(
                controller: _certCtrl,
                onChanged: (_) => setState((){}),
                validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                decoration: const InputDecoration(
                  labelText: 'Certificate Number *',
                  hintText: 'YPV-2024-001',
                  helperText: 'Must be unique system-wide',
                ),
              ),
            ]),
          ),
          const SizedBox(height: 20),
          PrimaryButton(label: 'Save Student', loading: _loading,
              onPressed: _valid ? _save : null),
        ],
      ),
    ),
  );

  String _monthName(int m) => const ['','Jan','Feb','Mar','Apr','May','Jun',
      'Jul','Aug','Sep','Oct','Nov','Dec'][m];
}
